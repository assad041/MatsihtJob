    
<?php
   include "header2.php";

?>



    <div class="container">        
        <div class="row">
            <div class="col-md-12">
                <br>
                <pre style='font-size:15px;font-weight:bold;'>
                <br>Expired Varification Code, Please Contact with System Administrator





                </pre>
            </div>
            
        </div>
    </div>

<?php
   include "footer.php";

?>