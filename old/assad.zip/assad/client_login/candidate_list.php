<?php
   $page='candidate_list';
   include './controller_master.php';
?>

