<?php
   $page='response';
   include './controller_master.php';
?>

