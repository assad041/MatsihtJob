<?php
   $page='accepted_list';
   include './controller_master.php';
?>

