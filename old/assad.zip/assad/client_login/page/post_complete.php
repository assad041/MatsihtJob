

<div class="main-page-title"><!-- start main page title -->
    <div class="container">        
        <div class="row">
            <div class="col-md-12">
                <br>
              <pre style="color:green;font-weight:bold;font-size:15px;text-align:center;">
               Congratulation ! Your Job circular is published successfully.
            <br><br><br><br>
             
           </pre>
             
                </pre>
            </div>
            
        </div>
    </div>
</div>