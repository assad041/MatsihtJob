<?php
   $page='profile';
   include './controller_master.php';
?>

