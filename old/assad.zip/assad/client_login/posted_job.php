<?php
   $page='posted_job';
   include './controller_master.php';
?>

