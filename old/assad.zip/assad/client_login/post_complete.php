<?php
   $page='post_com';
   include './controller_master.php';
?>
