<?php
   $page='drafted_job';
   include './controller_master.php';
?>

