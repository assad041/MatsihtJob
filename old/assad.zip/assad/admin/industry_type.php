<?php
   $page='industry_type';
   include './admin_master.php';
?>

