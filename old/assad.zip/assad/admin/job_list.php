<?php
   $page='job_list';
   include './admin_master.php';
?>

