<?php
   $page='content';
   include './admin_master.php';
?>

