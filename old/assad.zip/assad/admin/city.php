<?php
   $page='city';
   include './admin_master.php';
?>

