<?php
   $page='add_member_org';
   include './admin_master.php';
?>

