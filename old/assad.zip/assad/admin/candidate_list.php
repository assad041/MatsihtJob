<?php
   $page='candidate_list';
   include './admin_master.php';
?>

