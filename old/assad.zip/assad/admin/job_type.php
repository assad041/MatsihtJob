<?php
   $page='job_type';
   include './admin_master.php';
?>

