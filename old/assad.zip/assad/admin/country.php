<?php
   $page='country';
   include './admin_master.php';
?>

