<?php
   $page='verify';
   include './admin_master.php';
?>

