<?php
   $page='job_publish';
   include './admin_master.php';
?>

