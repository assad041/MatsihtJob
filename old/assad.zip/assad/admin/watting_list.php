<?php
   $page='watting_list';
   include './admin_master.php';
?>

