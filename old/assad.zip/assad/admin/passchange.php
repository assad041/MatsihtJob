<?php
   $page='passchange';
   include './admin_master.php';
?>

