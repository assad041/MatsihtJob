<?php
   $page='client_list';
   include './admin_master.php';
?>
