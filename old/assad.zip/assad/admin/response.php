<?php
   $page='response';
   include './admin_master.php';
?>
