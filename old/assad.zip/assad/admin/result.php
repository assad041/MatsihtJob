<?php
   $page='result';
   include './admin_master.php';
?>
