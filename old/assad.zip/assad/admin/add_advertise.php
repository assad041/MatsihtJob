<?php
   $page='add_advertise';
   include './admin_master.php';
?>

