<?php
   $page='accepted_list';
   include './admin_master.php';
?>

