<?php

header('Location: applicant_login/index.php');

?>
