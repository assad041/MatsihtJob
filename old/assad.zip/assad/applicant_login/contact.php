<?php
   $page='contact';
   include './controller_master.php';
?>

