<?php
   $page='uploadpicture';
   include './controller_master.php';
?>

