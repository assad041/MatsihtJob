<?php
   $page='uploaddocs';
   include './controller_master.php';
?>

