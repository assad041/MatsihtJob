<?php
   $page='academic';
   include './controller_master.php';
?>

