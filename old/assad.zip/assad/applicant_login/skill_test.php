<?php
   $page='skill_test';
   include './controller_master.php';
?>

