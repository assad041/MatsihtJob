<?php
   $page='update_profile';
   include './controller_master.php';
?>

