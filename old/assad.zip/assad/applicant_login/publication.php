<?php
   $page='publication';
   include './controller_master.php';
?>

