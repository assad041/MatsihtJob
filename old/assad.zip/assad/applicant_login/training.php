<?php
   $page='training';
   include './controller_master.php';
?>

