<?php

header('Location: client_login/index.php');

?>
